from xml.dom.minidom import Document
from django.db import models
from django.conf import settings

# Create your models here.

class Registration(models.Model):
    

    email = models.CharField(max_length=50,null=False)
    name = models.CharField(max_length=50,null=False)
    designation =models.CharField(max_length=50,null=False)
    #status = models.CharField(max_length=50,null=False)
    status = models.CharField(max_length=50,null=False ,default = 0)
    interviewer_link = models.URLField(max_length = 400,null=False ,default = 0)

    def __str__(self):
        #return self.title
        return self.name


     
