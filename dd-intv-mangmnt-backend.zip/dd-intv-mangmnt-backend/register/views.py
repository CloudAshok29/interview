from .models import Registration
from rest_framework import viewsets
from rest_framework import permissions
from .serializers import RegistrationSerializer


class RegistrationViewSet(viewsets.ModelViewSet):
    """
    API endpoint that allows register to be viewed or edited.
    """
    queryset = Registration.objects.all()
    serializer_class = RegistrationSerializer
    permission_classes = [permissions.AllowAny]