from rest_framework import serializers
from .models import Candidate_details


class Candidate_detailsSerializer(serializers.ModelSerializer):
    class Meta:
        model = Candidate_details
        fields = ['id','name_of_the_candidate','email','mobile_number','applied_domain','remarks','status','interviewer_name','interview_taken_time']
         

